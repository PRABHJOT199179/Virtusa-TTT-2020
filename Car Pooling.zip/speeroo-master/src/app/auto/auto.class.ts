export interface Auto {
  _id: any;
  owner: any;
  clients: any;
  description: any;
  destinations: [{'name': any, 'date': any}];
  constraints: any;
}
