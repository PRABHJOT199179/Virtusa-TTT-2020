export interface User {
  name: string,
  userId: string,
  peerId : string
}
