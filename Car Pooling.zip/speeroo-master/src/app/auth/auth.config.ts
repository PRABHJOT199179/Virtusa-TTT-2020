interface AuthConfiguration {
    clientID: string;
    domain: string;
}

export const AuthConfig: AuthConfiguration = {
    clientID: 'LtOnNFXioXiQEeFYL9XQVxArR75qkRNn',
    domain: 'lambdoid.auth0.com'
};
