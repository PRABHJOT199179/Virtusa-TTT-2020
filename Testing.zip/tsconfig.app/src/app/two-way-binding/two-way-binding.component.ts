import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-two-way-binding',
  templateUrl: './two-way-binding.component.html',
  styleUrls: ['./two-way-binding.component.css']
})
export class TwoWayBindingComponent implements OnInit {
  sometext: String;
  sometext1: String;
  constructor() { }

  ngOnInit(): void {
  }

  onEntery(textfield){
    this.sometext = (<HTMLInputElement>textfield.target).value;
    this.sometext = this.sometext.toUpperCase();
    this.sometext1 = this.sometext.toLowerCase();
  }
}
