import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-way-binding',
  templateUrl: './one-way-binding.component.html',
  styleUrls: ['./one-way-binding.component.css']
})
export class OneWayBindingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  animal:String;
  onNameEnter(textfield){
    this.animal = (<HTMLInputElement>textfield.target).value;
    console.log(this.animal);
  }

  clicked(){
    console.log("Button Clicked");
  }
}
