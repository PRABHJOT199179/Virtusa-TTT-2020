import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lifecycle',
  templateUrl: './lifecycle.component.html',
  styleUrls: ['./lifecycle.component.css']
})
export class LifecycleComponent implements OnInit {

  constructor() {
    console.log("In Constructor of Lifecycle component");
  }
  firstname:String
  lastname:String
  ngOnInit(): void {
    console.log("In ngOnInit of lifecycle component");
  }
  onSubmit(){
    console.log("Submit Button was clicked",this.firstname,this.lastname)
  }

}
