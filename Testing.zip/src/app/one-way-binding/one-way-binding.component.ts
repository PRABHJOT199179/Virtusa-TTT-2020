import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-way-binding',
  templateUrl: './one-way-binding.component.html',
  styleUrls: ['./one-way-binding.component.css']
})
export class OneWayBindingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  animal:String;
  but:Boolean = false;
  onNameEnter(textfield){
    
    this.animal = (<HTMLInputElement>textfield.target).value;
    this.animal = "./" + this.animal + ".jpg";
    console.log(this.animal);
  }

  showImage(){
    console.log("Button Clicked!");
    
    this.but = true;
  }
}
